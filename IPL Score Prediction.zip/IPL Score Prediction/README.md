# IPL Score Prediction Webapp
[Open In Google Colab](https://colab.research.google.com/github/thatfreakcoder/IPL-Score-Prediction-with-Machine-Learning/blob/master/IPL_Prediction_Model_Training.ipynb)</br>
The Webapp is deployed on **Heroku** [here](https://ipl-predict-score.herokuapp.com)</br>
All the trained pickle models can be found in `utilities` directory.</br>
The Training Notebook can be found [here](https://github.com/thatfreakcoder/IPL-Score-Prediction-with-Machine-Learning)</br>
The **Dataset** can be found [here](https://www.kaggle.com/yuvrajdagur/ipl-dataset-season-2008-to-2017)
